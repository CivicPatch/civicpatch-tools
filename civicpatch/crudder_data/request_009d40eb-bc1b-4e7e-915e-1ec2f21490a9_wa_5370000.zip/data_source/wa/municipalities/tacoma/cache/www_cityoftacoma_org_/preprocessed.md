* September 2 @ 9:00 am -

  Weekly hybrid hearings are held on Tuesdays for members of the public wishing to attend any scheduled public hearing and/or offer testimony.
* September 3 @ 5:00 pm -

  Planning Commission meetings are held on the first and third Wednesday of each month at 5:00 p.m.

[Aug

### Labor Day Observed by City of Tacoma on September 1](https://tacoma.gov/news/labor-day-observed-by-city-of-tacoma-on-september-1/)

[Aug

### An Update to the Community From Council Member Joe Bushnell on Fred Meyer Closure](https://tacoma.gov/news/an-update-to-the-community-from-council-member-joe-bushnell-on-fred-meyer-closure/)

[Aug

Today the City of Tacoma filed a response to a lawsuit brought against the City and Pierce County by…](https://tacoma.gov/news/city-of-tacoma-requests-dismissal-of-initiative-2-lawsuit/)

[Aug

### Asphalt Repairs to Bring Lane Closures at 72nd Street East and Portland Avenue East on September 6](https://tacoma.gov/news/asphalt-repairs-to-bring-lane-closures-at-72nd-street-east-and-portland-avenue-east-on-september-6/)

[Aug

### Council Member Sandesh Sadalge Passes Resolution 41740 to Fund ‘Grit of Destiny: City of Tacoma’](https://tacoma.gov/news/council-member-sandesh-sadalge-passes-resolution-41740-to-fund-grit-of-destiny-city-of-tacoma/)

[Aug](https://tacoma.gov/news/city-of-tacoma-partners-with-crown-castle-to-improve-fiber-installation/)

[Aug](https://tacoma.gov/news/hylebos-bridge-closed-to-vehicular-traffic-until-further-notice/)

[Aug

The City of Tacoma invites community members to the opening of the J Street Neighborhood Greenway on Thursday, September 4,…](https://tacoma.gov/news/celebrate-the-opening-of-the-j-street-neighborhood-greenway-in-tacomas-hilltop-neighborhood/)

September 1 @ 5:30 pm -

Tue

September 2 @ 9:00 am -

Tue

September 2 @ 10:00 am

[![](https://tacoma.gov/wp-content/uploads/2024/11/icon-open-data-100x40.png)](https://data.tacoma.gov)
[![](https://tacoma.gov/wp-content/uploads/2024/11/icon-emergency-49x48.png)](https://tacoma.gov/government/departments/fire/tacomas-emergency-notification-system/)
[![](https://tacoma.gov/wp-content/uploads/2024/11/icon-scale-51x48.png)](https://tacoma.gov/government/departments/equity-and-human-rights/equity-index/)
[![](https://tacoma.gov/wp-content/uploads/2024/11/icon-apply-48x48.png)](https://tacoma.gov/government/departments/human-resources/job-hub/)

![Kids Health and Safety Fair-August 23, 2025](https://img.youtube.com/vi/vsbmKZJ9AH0/maxresdefault.jpg)

Kids Health and Safety Fair-August 23, 2025

![2025 City of Destiny Awards Ceremony](https://img.youtube.com/vi/nAhoO3FQ_Ik/maxresdefault.jpg)

![Photo of the roller derby team](https://tacoma.gov/wp-content/uploads/2025/07/RollerDerbyTeam-437x248.png)

![](https://tacoma.gov/wp-content/uploads/2024/12/311logo_2024-437x248.png)

![See You in Tacoma](https://img.youtube.com/vi/raq0BPuNa3M/maxresdefault.jpg)

![Rylee Pay New Tacoma Rainiers Broadcaster next to banner of Rainiers](https://tacoma.gov/wp-content/uploads/2025/05/RyleePayTacomaRainers-437x248.png)

Tacoma Report - Rylee Pay, Tacoma Rainiers new Play-by-Play Broadcaster

[![Photo of Mayor Victoria Woodards](https://tacoma.gov/wp-content/uploads/2024/11/Mayor-Woodards-Portrait-1-312x300.jpg)

### Victoria Woodards](https://tacoma.gov/government/departments/mayor/)
[![Photo of the Tacoma City Council.](https://tacoma.gov/wp-content/uploads/2025/02/Council-Portrait2025-Extended-Square-Edit.jpg)](https://tacoma.gov/government/departments/city-council/)
[![Hyun Kim](https://tacoma.gov/wp-content/uploads/2025/05/Hyun-Kim-312x300.jpg)

### Hyun Kim](https://tacoma.gov/government/departments/city-managers-office/)
[![Photo of the Municipal Court Judges in a court room.](https://tacoma.gov/wp-content/uploads/2025/05/MunicipalCourtJudges2025-312x300.jpg)](https://tacoma.gov/government/departments/municipal-court/)

![](https://tacoma.gov/wp-content/uploads/2024/11/rsz_foss_waterway_aerial_picture-1600x630.jpg)