City of Tacoma, Washington - Official Government Website




































































 







[Skip to main content](https://tacoma.gov/#main)

Menu


* [Services](https://tacoma.gov/services/)



  Expand Services Links

  + [Accessibility and ADA](https://tacoma.gov/services/accessibility-and-ada/)
  + [Animal Resources](https://tacoma.gov/services/animal-resources/)
  + [Business](https://tacoma.gov/services/business/)
  + [Contracting](https://tacoma.gov/i-want-to/contracting-opportunities/)
  + [Development Services](https://tacoma.gov/government/departments/planning-and-development-services/)
  + [Employment Resources](https://tacoma.gov/government/departments/human-resources/)
  + [Emergency Management](https://tacoma.gov/government/departments/fire/emergency-management-program/)
  + [Fire](https://tacoma.gov/government/departments/fire/)
  + [Garbage & Recycling](https://tacoma.gov/services/garbage-recycling/)
  + [Guides to Tacoma](https://tacoma.gov/services/guides-to-tacoma/)
  + [Homelessness](https://tacoma.gov/government/departments/neighborhood-and-community-services/homelessness-services/)
  + [Housing](https://tacoma.gov/i-want-to/housing-information/)
  + [Library](https://www.tacomalibrary.org/)
  + [Parking](https://tacoma.gov/guide/parking-in-tacoma/)
  + [Permits](https://tacoma.gov/i-want-to/apply-for-a-permit/)
  + [Police & Safety](https://tacoma.gov/government/departments/police/)
  + [Procurement](https://tacoma.gov/government/departments/finance/procurement-and-payables-division/)
  + [Public Records](https://tacoma.mycusthelp.com/WEBAPP/_rs/(S(pktt0ut0vyubph2cxgjpkrwc))/supporthome.aspx)
  + [Residents](https://tacoma.gov/services/residents/)
  + [Tacoma FIRST 311](https://tacoma.gov/services/tacoma-first-311-services/)
  + [Tacoma Open Data & Maps](https://tacoma.gov/services/tacoma-open-data-maps/)
  + [TAGRO](https://tacoma.gov/government/departments/environmental-services/tagro/)
  + [Tax & License](https://tacoma.gov/government/departments/finance/taxes-and-licenses/)
  + [Transportation & Roads](https://tacoma.gov/services/transportation-roads/)
  + [Utilities](https://tacoma.gov/services/utilities/)
  + [Visitor Information](https://tacoma.gov/i-want-to/about-tacoma/)
  + [Volunteer Opportunities](https://tacoma.gov/i-want-to/serve-volunteer/)
  + [View All Services](https://tacoma.gov/services/)
* [Government](https://tacoma.gov/government/)



  Expand Government Links

  + [City Council](https://tacoma.gov/government/departments/city-council/)
  + [Committees, Boards, and Commissions](https://tacoma.gov/government/committees-boards-and-commissions/)
  + [Departments](https://tacoma.gov/government/departments/)
  + [Elections](https://tacoma.gov/government/elections/)
  + [Mayor](https://tacoma.gov/government/departments/mayor/)
  + [Municipal Court](https://tacoma.gov/government/departments/municipal-court/)
* [City Projects](https://tacoma.gov/city-projects/)
* [News](https://tacoma.gov/tacoma-newsroom/)
* [Events](https://tacoma.gov/events/)
* [Help & Contact Us](https://tacoma.gov/help-contact-us/)
* [I Want To](https://tacoma.gov/i-want-to/)



  Expand I Want To Links

  + Apply

    - [For a License](https://tacoma.gov/i-want-to/for-a-license/)
    - [For a Permit](https://tacoma.gov/i-want-to/for-a-permit/)
    - [For a Job](https://tacoma.gov/government/departments/human-resources/job-hub/)
    - [To Serve/Volunteer](https://tacoma.gov/i-want-to/to-serve-volunteer/)
  + File

    - [A Police Report](https://tacoma.gov/government/departments/police/tpd-services/)
    - [A 311 Service Request/Report](https://tacoma.gov/services/tacoma-first-311-services/)
    - [A Complaint](https://cms.tacoma.gov/tacomafirst311)
  + Find

    - [Animal Licensing Information](https://tacoma.gov/government/departments/finance/taxes-and-licenses/animal-licensing/)
    - [City Data & Dashboards](https://tacoma.gov/services/tacoma-open-data-maps/)
    - [Contracting Opportunities](https://tacoma.gov/government/departments/finance/procurement-and-payables-division/purchasing/contracting-opportunities/)
    - [Waste and Recycling Schedule](https://tacoma.gov/government/departments/environmental-services/solid-waste/collection-schedule/)
    - [Waste Services Information](https://tacoma.gov/government/departments/environmental-services/solid-waste/)
    - [Housing Information](https://tacoma.gov/i-want-to/housing-information/)
    - [Homelessness Services](https://tacoma.gov/government/departments/neighborhood-and-community-services/homelessness-services/)
    - [Libraries](https://www.tacomalibrary.org/ )
    - [Parks](https://www.metroparkstacoma.org/ )
    - [Parking](https://tacoma.gov/government/departments/public-works/parking/)
  + Learn About

    - [Tacoma](https://tacoma.gov/i-want-to/about-tacoma/)
    - [City Council Priorities](https://tacoma.gov/government/departments/city-council/)
    - [Our Mission & Values](https://tacoma.gov/government/)
    - [Emergency Preparedness](https://tacoma.gov/i-want-to/about-emergency-management-preparedness/)
    - [Policing Accountability & Transparency](https://tacoma.gov/government/departments/police/policing-accountability-transparency/)
  + Pay

    - [Utility Bills](https://www.mytpu.org/payment-billing/payment-information/ways-to-pay/)
    - [Municipal Court Fees/Tickets](https://wacljtmc.municipalonlinepayments.com/wacljtmc)
    - [B&O Taxes](https://tacoma.gov/government/departments/finance/taxes-and-licenses/city-taxes/tax-types/)
    - [Permit Fees](https://aca-prod.accela.com/TACOMA/Default.aspx)
    - [More Options](https://tacoma.gov/government/departments/finance/payment-portals/)
  + Register

    - [My Business in Tacoma](https://tacoma.gov/i-want-to/register-my-business-in-tacoma/)
    - [To Vote](https://www.piercecountywa.gov/6572/Register-to-Vote)
  + Request

    - [Police Records](https://southsound911.org/public-records-requests/)
    - [Public Records](https://tacoma.gov/government/departments/public-records-office/)
  + View

    - [City Council Agenda, Minutes, and Meetings](https://tacoma.gov/i-want-to/city-council-agendas-minutes-and-meetings/)
    - [City Council](https://tacoma.gov/government/departments/city-council/)
    - [City Projects](https://tacoma.gov/city-projects/)
    - [Crime Statistics](https://public.tableau.com/app/profile/city.of.tacoma/viz/TacomaPoliceCrimeDashboard/CrimeDashboard-IntroPage)
    - [City Codes](https://tacoma.gov/government/departments/city-clerks-office/tacoma-municipal-code/)
  + [View More](https://tacoma.gov/i-want-to/)

* [Contact Us](https://tacoma.gov/help-contact-us/)
* [Employment](https://tacoma.gov/government/departments/human-resources/job-hub/)
* [English▼](https://tacoma.gov/#)

  [Afrikaans](https://tacoma.gov/af/) [Albanian](https://tacoma.gov/sq/) [Amharic](https://tacoma.gov/am/) [Arabic](https://tacoma.gov/ar/) [Armenian](https://tacoma.gov/hy/) [Azerbaijani](https://tacoma.gov/az/) [Basque](https://tacoma.gov/eu/) [Belarusian](https://tacoma.gov/be/) [Bengali](https://tacoma.gov/bn/) [Bosnian](https://tacoma.gov/bs/) [Bulgarian](https://tacoma.gov/bg/) [Catalan](https://tacoma.gov/ca/) [Cebuano](https://tacoma.gov/ceb/) [Chichewa](https://tacoma.gov/ny/) [Chinese (Simplified)](https://tacoma.gov/zh-CN/) [Chinese (Traditional)](https://tacoma.gov/zh-TW/) [Corsican](https://tacoma.gov/co/) [Croatian](https://tacoma.gov/hr/) [Czech](https://tacoma.gov/cs/) [Danish](https://tacoma.gov/da/) [Dutch](https://tacoma.gov/nl/) [English](https://tacoma.gov/) [Esperanto](https://tacoma.gov/eo/) [Estonian](https://tacoma.gov/et/) [Filipino](https://tacoma.gov/tl/) [Finnish](https://tacoma.gov/fi/) [French](https://tacoma.gov/fr/) [Frisian](https://tacoma.gov/fy/) [Galician](https://tacoma.gov/gl/) [Georgian](https://tacoma.gov/ka/) [German](https://tacoma.gov/de/) [Greek](https://tacoma.gov/el/) [Gujarati](https://tacoma.gov/gu/) [Haitian Creole](https://tacoma.gov/ht/) [Hausa](https://tacoma.gov/ha/) [Hawaiian](https://tacoma.gov/haw/) [Hebrew](https://tacoma.gov/iw/) [Hindi](https://tacoma.gov/hi/) [Hmong](https://tacoma.gov/hmn/) [Hungarian](https://tacoma.gov/hu/) [Icelandic](https://tacoma.gov/is/) [Igbo](https://tacoma.gov/ig/) [Indonesian](https://tacoma.gov/id/) [Irish](https://tacoma.gov/ga/) [Italian](https://tacoma.gov/it/) [Japanese](https://tacoma.gov/ja/) [Javanese](https://tacoma.gov/jw/) [Kannada](https://tacoma.gov/kn/) [Kazakh](https://tacoma.gov/kk/) [Khmer](https://tacoma.gov/km/) [Korean](https://tacoma.gov/ko/) [Kurdish (Kurmanji)](https://tacoma.gov/ku/) [Kyrgyz](https://tacoma.gov/ky/) [Lao](https://tacoma.gov/lo/) [Latin](https://tacoma.gov/la/) [Latvian](https://tacoma.gov/lv/) [Lithuanian](https://tacoma.gov/lt/) [Luxembourgish](https://tacoma.gov/lb/) [Macedonian](https://tacoma.gov/mk/) [Malagasy](https://tacoma.gov/mg/) [Malay](https://tacoma.gov/ms/) [Malayalam](https://tacoma.gov/ml/) [Maltese](https://tacoma.gov/mt/) [Maori](https://tacoma.gov/mi/) [Marathi](https://tacoma.gov/mr/) [Mongolian](https://tacoma.gov/mn/) [Myanmar (Burmese)](https://tacoma.gov/my/) [Nepali](https://tacoma.gov/ne/) [Norwegian](https://tacoma.gov/no/) [Pashto](https://tacoma.gov/ps/) [Persian](https://tacoma.gov/fa/) [Polish](https://tacoma.gov/pl/) [Portuguese](https://tacoma.gov/pt/) [Punjabi](https://tacoma.gov/pa/) [Romanian](https://tacoma.gov/ro/) [Russian](https://tacoma.gov/ru/) [Samoan](https://tacoma.gov/sm/) [Scottish Gaelic](https://tacoma.gov/gd/) [Serbian](https://tacoma.gov/sr/) [Sesotho](https://tacoma.gov/st/) [Shona](https://tacoma.gov/sn/) [Sindhi](https://tacoma.gov/sd/) [Sinhala](https://tacoma.gov/si/) [Slovak](https://tacoma.gov/sk/) [Slovenian](https://tacoma.gov/sl/) [Somali](https://tacoma.gov/so/) [Spanish](https://tacoma.gov/es/) [Sundanese](https://tacoma.gov/su/) [Swahili](https://tacoma.gov/sw/) [Swedish](https://tacoma.gov/sv/) [Tajik](https://tacoma.gov/tg/) [Tamil](https://tacoma.gov/ta/) [Telugu](https://tacoma.gov/te/) [Thai](https://tacoma.gov/th/) [Turkish](https://tacoma.gov/tr/) [Ukrainian](https://tacoma.gov/uk/) [Urdu](https://tacoma.gov/ur/) [Uzbek](https://tacoma.gov/uz/) [Vietnamese](https://tacoma.gov/vi/) [Welsh](https://tacoma.gov/cy/) [Xhosa](https://tacoma.gov/xh/) [Yiddish](https://tacoma.gov/yi/) [Yoruba](https://tacoma.gov/yo/) [Zulu](https://tacoma.gov/zu/)
* Search
  Search

[![

](https://tacoma.gov/wp-content/uploads/2024/11/rsz_foss_waterway_aerial_picture-1600x630@2x.jpg)](https://tacoma.gov/wp-content/uploads/2024/08/tacoma-video-compressed.mp4)

City of Tacoma
==============

Search

Search

Search

Trending in Tacoma
------------------

* September 2 @ 9:00 am - 10:00 am

  ### [Hearing Examiner’s Hearing](https://tacoma.gov/event/hearing-examiners-hearing-2/)Event

  Weekly hybrid hearings are held on Tuesdays for members of the public wishing to attend any scheduled public hearing and/or offer testimony.
* September 3 @ 5:00 pm - 7:00 pm

  ### [Tacoma Planning Commission Meeting](https://tacoma.gov/event/tacoma-planning-commission-meeting-first-wed-2/)Event

  Planning Commission meetings are held on the first and third Wednesday of each month at 5:00 p.m.
* ### [Labor Day Observed by City of Tacoma on September 1](https://tacoma.gov/news/labor-day-observed-by-city-of-tacoma-on-september-1/)News

  Administrative offices in the Tacoma Municipal Building complex…
* ### [City of Tacoma Requests Dismissal of Initiative 2 Lawsuit](https://tacoma.gov/news/city-of-tacoma-requests-dismissal-of-initiative-2-lawsuit/)News

  Today the City of Tacoma filed a…

[Tacoma City Council](https://tacoma.gov/government/departments/city-council/)
[Garbage and Recycling](https://tacoma.gov/services/garbage-recycling/)
[Permitting](https://tacoma.gov/i-want-to/apply-for-a-permit/)
[Make a Payment](https://tacoma.gov/government/departments/finance/payment-portals/)

Tacoma FIRST 311 Make a Report or Request
-----------------------------------------

[View All](https://tacoma.gov/services/tacoma-first-311-services/)

[Ask a Question](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39591/location)
[Abandoned Vehicle on Street](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39602)
[Animal Issue](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39615)
[Garbage / Debris on Private Property](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39665/location)
[Garbage / Illegal Dumping on Public Property](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39637)
[Homeless Encampment](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39612)
[Landlord-Tenant Intake Form](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39638/location)
[Noise Complaint](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39614)
[Overgrown Vegetation - Private Property](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39690)
[Parking Issues](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39679)
[Pothole / Street Repair](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39646)
[Someone Living in Motor Home / Vehicle](https://seeclickfix.com/web_portal/Mx4UcnjshtJ83uMYFA2D58p5/report/category/39643)

Latest News
-----------

[View All](https://tacoma.gov/tacoma-newsroom/news-list/)

[Aug

29

### Labor Day Observed by City of Tacoma on September 1

Administrative offices in the Tacoma Municipal Building complex (747 Market St. and 733 Market St.) and in other City of…](https://tacoma.gov/news/labor-day-observed-by-city-of-tacoma-on-september-1/)

[Aug

27

### An Update to the Community From Council Member Joe Bushnell on Fred Meyer Closure

“I remain deeply disappointed by the decision to close the Fred Meyer store on 72nd Street, a staple in our…](https://tacoma.gov/news/an-update-to-the-community-from-council-member-joe-bushnell-on-fred-meyer-closure/)

[Aug

22

### City of Tacoma Requests Dismissal of Initiative 2 Lawsuit

Today the City of Tacoma filed a response to a lawsuit brought against the City and Pierce County by…](https://tacoma.gov/news/city-of-tacoma-requests-dismissal-of-initiative-2-lawsuit/)

[Aug

21

### Asphalt Repairs to Bring Lane Closures at 72nd Street East and Portland Avenue East on September 6

The City of Tacoma’s Public Works Department – Street Operations Division will perform asphalt repairs at the intersection of 72nd…](https://tacoma.gov/news/asphalt-repairs-to-bring-lane-closures-at-72nd-street-east-and-portland-avenue-east-on-september-6/)

[Aug

19

### Council Member Sandesh Sadalge Passes Resolution 41740 to Fund ‘Grit of Destiny: City of Tacoma’

Tonight, the City Council unanimously adopted Resolution 41740, authorizing an expenditure of $15,000 from the Council Contingency Fund in support…](https://tacoma.gov/news/council-member-sandesh-sadalge-passes-resolution-41740-to-fund-grit-of-destiny-city-of-tacoma/)

[Aug

19

### City of Tacoma Partners with Crown Castle to Improve Fiber Installation

The City of Tacoma is partnering with Crown Castle, the nation’s largest provider of shared communications infrastructure, to pilot an…](https://tacoma.gov/news/city-of-tacoma-partners-with-crown-castle-to-improve-fiber-installation/)

[Aug

19

### Hylebos Bridge Closed to Vehicular Traffic Until Further Notice

The Hylebos Bridge (located off East 11th Street in the Tacoma Tideflats) is currently closed to vehicular…](https://tacoma.gov/news/hylebos-bridge-closed-to-vehicular-traffic-until-further-notice/)

[Aug

18

### Celebrate the Opening of the J Street Neighborhood Greenway in Tacoma’s Hilltop Neighborhood

The City of Tacoma invites community members to the opening of the J Street Neighborhood Greenway on Thursday, September 4,…](https://tacoma.gov/news/celebrate-the-opening-of-the-j-street-neighborhood-greenway-in-tacomas-hilltop-neighborhood/)

Slide Left



Side Right

Upcoming Events
---------------

[View All Events](https://tacoma.gov/events/)

Mon

1

September 1 @ 5:30 pm - 7:30 pm

### [Tacoma Creates Advisory Board Meeting](https://tacoma.gov/event/tacoma-creates-advisory-board-meeting-2-3/)

Tue

2

September 2 @ 9:00 am - 10:00 am

### [Hearing Examiner’s Hearing](https://tacoma.gov/event/hearing-examiners-hearing-2/)

Tue

2

September 2 @ 10:00 am

### [Government Performance and Finance Committee Meeting](https://tacoma.gov/event/government-performance-and-finance-committee-3/)

Featured Resources
------------------

[![](https://tacoma.gov/wp-content/uploads/2024/11/icon-open-data-100x40.png)

View Open Data](https://data.tacoma.gov)
[![](https://tacoma.gov/wp-content/uploads/2024/11/icon-emergency-49x48.png)

Sign Up for Emergency Notifications](https://tacoma.gov/government/departments/fire/tacomas-emergency-notification-system/)
[![](https://tacoma.gov/wp-content/uploads/2024/11/icon-scale-51x48.png)

View Equity Index](https://tacoma.gov/government/departments/equity-and-human-rights/equity-index/)
[![](https://tacoma.gov/wp-content/uploads/2024/11/icon-apply-48x48.png)

Apply for a City Job](https://tacoma.gov/government/departments/human-resources/job-hub/)

Tacoma Video Highlights
-----------------------

[Watch TV Tacoma](https://tacoma.gov/government/departments/media-and-communications-office/tv-tacoma/)

![Kids Health and Safety Fair-August 23, 2025](https://img.youtube.com/vi/vsbmKZJ9AH0/maxresdefault.jpg)

Kids Health and Safety Fair-August 23, 2025



Close

![2025 City of Destiny Awards Ceremony](https://img.youtube.com/vi/nAhoO3FQ_Ik/maxresdefault.jpg)

2025 City of Destiny Awards Ceremony



Close

![Photo of the roller derby team](https://tacoma.gov/wp-content/uploads/2025/07/RollerDerbyTeam-437x248.png)

Profile: Dockyard Roller Derby Team



Close

![](https://tacoma.gov/wp-content/uploads/2024/12/311logo_2024-437x248.png)

How Tacoma FIRST 311 Works



Close

![See You in Tacoma](https://img.youtube.com/vi/raq0BPuNa3M/maxresdefault.jpg)

See You in Tacoma



Close

![Rylee Pay New Tacoma Rainiers Broadcaster next to banner of Rainiers](https://tacoma.gov/wp-content/uploads/2025/05/RyleePayTacomaRainers-437x248.png)

Tacoma Report - Rylee Pay, Tacoma Rainiers new Play-by-Play Broadcaster



Close

Slide Left



Side Right

City Government
---------------

[![Photo of Mayor Victoria Woodards](https://tacoma.gov/wp-content/uploads/2024/11/Mayor-Woodards-Portrait-1-312x300.jpg)

Mayor

### Victoria Woodards](https://tacoma.gov/government/departments/mayor/)
[![Photo of the Tacoma City Council.](https://tacoma.gov/wp-content/uploads/2025/02/Council-Portrait2025-Extended-Square-Edit.jpg)

Tacoma City Council

### City Council](https://tacoma.gov/government/departments/city-council/)
[![Hyun Kim](https://tacoma.gov/wp-content/uploads/2025/05/Hyun-Kim-312x300.jpg)

City Manager

### Hyun Kim](https://tacoma.gov/government/departments/city-managers-office/)
[![Photo of the Municipal Court Judges in a court room.](https://tacoma.gov/wp-content/uploads/2025/05/MunicipalCourtJudges2025-312x300.jpg)

Tacoma Municipal Court

### Municipal Court](https://tacoma.gov/government/departments/municipal-court/)

![](https://tacoma.gov/wp-content/uploads/2024/11/rsz_foss_waterway_aerial_picture-1600x630.jpg)

Get Involved and Serve Tacoma
-----------------------------

Looking to get more involved in our community? Apply to serve on one of Tacoma's Committees, Boards, and Commissions.

[Learn More](https://tacoma.gov/government/committees-boards-and-commissions/)

Sign Up to Receive Updates from the City of Tacoma
--------------------------------------------------

[Sign Up](https://public.govdelivery.com/accounts/WATACOMA/subscriber/new)

### Were you able to find what you were looking for?

 Yes   No

### What were you looking for?

   Submit

### Thank you for your feedback!

### Thank you for your feedback!

747 Market Street  
Tacoma, WA 98402  
(253) 591-5000

[Contact Us](https://tacoma.gov/help-contact-us/#contact)

* [Services](https://tacoma.gov/services/)
* [Government](https://tacoma.gov/government/)
* [City Projects](https://tacoma.gov/city-projects/)
* [News](https://tacoma.gov/tacoma-newsroom/)
* [Events](https://tacoma.gov/events/)
* [Help & Contact Us](https://tacoma.gov/help-contact-us/)

All content © 2025 City of Tacoma [\*](https://tacoma.gov/access/) | [Privacy Policy](https://tacoma.gov/data-privacy-policy/) |
[ADA Policy](https://tacoma.gov/ada-title-ii-policy/) |
[Disclaimer](https://tacoma.gov/city-of-tacoma-website-disclaimer/) |
[Employee Resources](https://tacoma.gov/government/departments/human-resources/)

Search

search

Close




























 


Notifications