City Council Member Zack Zappone - City of Spokane, Washington



##### Checking Your Browser

One Moment...Continue

Ensure browser cookies and javascript are enabled.

* [City of Spokane](https://my.spokanecity.org/ "City of Spokane Home Page")
* [spokanecity](https://my.spokanecity.org/website/map/ "Website Map & Sections")
* [Site Menu](https://my.spokanecity.org/ "Website Menu")

  + [live](https://my.spokanecity.org/live/ "Living in Spokane")
  + [work](https://my.spokanecity.org/work/ "Working & Doing Business")
  + [enjoy](https://my.spokanecity.org/enjoy/ "Enjoying & Visiting")
  + [engage](https://my.spokanecity.org/engage/ "Engaging & Getting Involved")
* [Search](https://my.spokanecity.org/search/ "Website Search")
* [My Account](https://my.spokanecity.org/account/ "My Account")

[Menu](https://my.spokanecity.org/citycouncil/members/zack-zappone/#)

* [City Council](https://my.spokanecity.org/citycouncil/)More
  + [Council Members](https://my.spokanecity.org/citycouncil/members/)
  + [Items of Interest](https://my.spokanecity.org/citycouncil/items-of-interest/)
  + [Meetings](https://my.spokanecity.org/citycouncil/meetings/)
  + [Documents](https://my.spokanecity.org/citycouncil/documents/)
  + [FAQs](https://my.spokanecity.org/citycouncil/faqs/)
  + [Blogs](https://my.spokanecity.org/citycouncil/blogs/)
  + [Video Programs](https://my.spokanecity.org/citycouncil/videos/)
* [Council Members](https://my.spokanecity.org/citycouncil/members/)More
  + [Betsy Wilkerson](https://my.spokanecity.org/citycouncil/members/betsy-wilkerson/)
  + [Jonathan Bingle](https://my.spokanecity.org/citycouncil/members/jonathan-bingle/)
  + [Michael Cathcart](https://my.spokanecity.org/citycouncil/members/michael-cathcart/)
  + [Paul Dillon](https://my.spokanecity.org/citycouncil/members/paul-dillon/)
  + [Shelby Lambdin](https://my.spokanecity.org/citycouncil/members/shelby-lambdin/)
  + [Zack Zappone](https://my.spokanecity.org/citycouncil/members/zack-zappone/)
  + [Kitty Klitzke](https://my.spokanecity.org/citycouncil/members/kitty-klitzke/)
* [Zack Zappone](https://my.spokanecity.org/citycouncil/members/zack-zappone/)

[City Council](https://my.spokanecity.org/citycouncil/default.aspx "City Council")
==================================================================================

* Previous
* Next

Zack Zappone
------------

![Zack Zappone](//static.spokanecity.org/photos/2024/12/05/zack-zappone/3x4/medium/zack-zappone.jpg)

*City Council Member, District 3*
  
Term: 2022-2025
  
[zzappone@spokanecity.org](mailto:zzappone@spokanecity.org)

Council Member Zappone represents northwest Spokane. He is a sixth-generation Eastern Washingtonian, teacher, and public health worker. He is dedicated to advocating for all people.

Zack saw first-hand that no matter how hard his students worked, they continued to face obstacles to upward mobility outside of the classroom. He saw that the lack of access to healthcare services, safe walking routes to school, or living-wage jobs continued to be a barrier to equity and a stronger community for his students. He currently teaches English part-time at his alma mater, North Central High School.

Zack is passionate about serving our community, volunteering with community vaccine clinics like the Native Project. He also served with the Spokane Food Fighters during the Coronavirus pandemic, witnessing the extent of income inequality and hardship in the community while helping to deliver over 100,000 meals to Spokanites in need.

Zack graduated from Georgetown University and has a master’s in public affairs from Princeton University. Zack is focused on creating ways to lift up working and middle class families, and to serve our community to make sure everyone has a fair shot.

#### Current Council Related Boards, Committees and Commissions

* [Finance and Administration Committee](https://my.spokanecity.org/bcc/committees/finance-and-administration/), Member
  + [Association of Washington Cities](https://wacities.org/about-us/board-of-directors)
  + Fiscal Impact Workgroup
  + Legislative Committee
  + [Tourism and Cultural Investment Committee (TACI)](https://my.spokanecity.org/bcc/committees/tourism-and-cultural-investment-committee/)
  + [TPA/Hotel-Motel Commission](https://my.spokanecity.org/bcc/commissions/hotel-advisory-commission/)
  + [Visit Spokane](http://www.visitspokane.com/)
* [Public Infrastructure, Environment and Sustainability Committee](https://my.spokanecity.org/bcc/committees/public-infrastructure-environment-and-sustainability/), Member
  + [Spokane Transit Authority (STA)](https://my.spokanecity.org/bcc/boards/spokane-transit-authority/)
  + [Transportation Commission](https://my.spokanecity.org/bcc/commissions/transportation-commission/) Liaison
* [Public Safety & Community Health Committee](https://my.spokanecity.org/bcc/committees/public-safety-and-community-health/), Chair
  + [Police Advisory Committee](https://my.spokanecity.org/bcc/committees/police-advisory-committee/)
* [Urban Experience Committee](https://my.spokanecity.org/bcc/committees/urban-development/), Member
  + Regional Homeless Authority

#### Legislative Assistant

Jackson Deese  
[509.625.6718](tel:509.625.6718)  
[jdeese@spokanecity.org](mailto:jdeese@spokanecity.org)

#### Voting History

Show 102550100 entries

Search:

| Date | Description | Vote |
| --- | --- | --- |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36723** - Titled “Public Dollars For Public Benefit,” relating to City public works; enacting a new Article XI, Chapter 07.06.800 of the Spokane Municipal Code, and setting an effective date. | Yea |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36729** - Amending Ordinance C-35052 that vacated portions of Dakota Street in the City of Spokane. | Yea |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36730** - Amending Ordinance C-36730 that vacated portions of Boone Avenue, Desmet Avenue, and Dakota Street in the City of Spokane. | Yea |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36731** - Amending Ordinance C-27061 that vacated portions of Boone Ave, Astor St, and Sharp Ave in the City of Spokane. | Yea |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36734** - Relating to fees and charges amending Chapter 08.02 of the Spokane Municipal Code. Specifically amending Section 08.02.065 Streets and Airspace and other matters properly related thereto | Yea |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36737** - Code clean-up ordinance removing expired SMC Chapter 09.01 as a result of a sunset provision triggered upon the passage and implementation of I-1433 in 2016; repealing Chapter 09.01 of the Spokane Municipal Code. | Yea |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36740** - Titled “Safe and Welcome in Spokane”, expanding protections against warrantless searches from immigration enforcement in designated nonpublic areas, amending sections 12.05.005, 12.05.060, and 12.05.070 of the Spokane Municipal Code. | Yea |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36744** - Final Reading Ordinance C36744 related to the designation of and requirements for streets, alleys, and driveways; amending Spokane Municipal Code sections 17A.020.030, .040, .120, .160, 17C.111.340, and 17H.010.010, .090, .130; and creating a new section 17H.010.015. | Yea |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36745** - Final Reading Ordinance C36745 related to roadway naming and addressing standards, amending Spokane Municipal Code sections 17D.050A.040, .050, .100, and .160. | Yea |
| [08/25/25](https://my.spokanecity.org/citycouncil/meetings/2025/08/25/legislative-meeting/) | **Ordinance C36746** - Maximizing community partnership grant opportunities; amending Section 07.19.010 of the Spokane Municipal Code | Yea |

Showing 1 to 10 of 944 entries

Previous12345…95Next

---

#### District 3 Weekly Newsletter

Sign up to get weekly updates from Council Members Klitzke & Zappone!

[Newsletter Sign-up](http://eepurl.com/jhWfYQ)

*The City of Choice*

---

#### City Council

808 W. Spokane Falls Blvd.
  
Spokane, WA 99201
  
[509.625.6255](tel:1-509-625-6255)

* [X/Twitter](https://twitter.com/spokane_council "Follow us on X/Twitter")
* [Facebook](https://facebook.com/spokanecitycouncil/ "Find us on Facebook")
* [Vimeo](https://vimeo.com/spokanecitycouncil "Watch us on Vimeo")

* spokanecity

* [Business & Development](https://my.spokanecity.org/business/ "Business & Development")
  + [Commercial](https://my.spokanecity.org/business/commercial/ "Commercial Services")
  + [Residential](https://my.spokanecity.org/business/residential/ "Residential Services")
  + [Resources](https://my.spokanecity.org/business/resources/ "Business & Development Resources")
* [City Hall](https://my.spokanecity.org/cityhall/ "City Hall")
  + [Mayor](https://my.spokanecity.org/mayor/ "Office of the Mayor")
  + [City Council](https://my.spokanecity.org/citycouncil/ "City Council")
  + [Hearing Examiner](https://my.spokanecity.org/hearingexaminer/ "Hearing Examiner")
* [Library](http://www.spokanelibrary.org/ "Spokane Public Library")
  + [Locations](http://www.spokanelibrary.org/open/ "Library Locations")
  + [Digital Branch](http://www.spokanelibrary.org/digital/ "Digital Branch")
  + [Services](http://www.spokanelibrary.org/services/ "Library Services")
  + [Events](http://www.spokanelibrary.org/calendar/ "Library Events")
* [CityCable5](https://my.spokanecity.org/citycable5/ "CityCable5")
  + [Programs](https://my.spokanecity.org/citycable5/programs/ "CityCable5 Programs")
  + [Schedule](https://my.spokanecity.org/citycable5/schedule/ "CityCable5 Schedule")
  + [Videos](https://my.spokanecity.org/citycable5/videos/ "CityCable5 Video Library")
  + [Live](https://my.spokanecity.org/citycable5/live/ "Watch CityCable5 Live")
* [Parks & Recreation](https://my.spokanecity.org/parksrec/ "Parks & Recreation")
  + [Parks](https://my.spokanecity.org/parks/ "Parks")
  + [Recreation](https://my.spokanecity.org/recreation/ "Recreation")
  + [Riverfront Spokane](https://my.spokanecity.org/riverfrontspokane/ "Riverfront Spokane")
  + [Golf](https://my.spokanecity.org/golf/ "Golf")
* [Police Department](https://my.spokanecity.org/police/ "Police Department")
  + [Patrol](https://my.spokanecity.org/police/patrol/ "Patrol")
  + [Investigations](https://my.spokanecity.org/police/investigations/ "Investigations")
  + [Prevention](https://my.spokanecity.org/police/prevention/ "Prevention")
* [Courts](https://my.spokanecity.org/courts/ "Courts")
  + [Municipal Court](https://my.spokanecity.org/courts/municipal-court/ "Municipal Court")
  + [Probation](https://my.spokanecity.org/courts/probation/ "Probation Services")
  + [Public Defender](https://my.spokanecity.org/courts/public-defender/ "Public Defender")
* [Fire Department](https://my.spokanecity.org/fire/ "Fire Department")
  + [Operations](https://my.spokanecity.org/fire/operations/ "Operations")
  + [Prevention](https://my.spokanecity.org/fire/prevention/ "Prevention")
  + [Training](https://my.spokanecity.org/fire/training/ "Training")
* [Community](https://my.spokanecity.org/community/ "Community Services")
  + [CHHS](https://my.spokanecity.org/chhs/ "Community, Housing, and Human Services")
  + [Neighborhoods](https://my.spokanecity.org/neighborhoods/ "Neighborhoods")
  + [Code Enforcement](https://my.spokanecity.org/codeenforcement/ "Code Enforcement")
* [Public Works & Utilities](https://my.spokanecity.org/publicworks/ "Public Works & Utilities")
  + [Streets](https://my.spokanecity.org/streets/ "Streets")
  + [Household](https://my.spokanecity.org/household/ "Household Services")
  + [Utilities](https://my.spokanecity.org/publicworks/utility-billing/ "Utility Billing")
  + [Environment](https://my.spokanecity.org/publicworks/environmental/ "Environmental Services")
* [OpenData](https://my.spokanecity.org/opendata/)
  + [Charter](https://my.spokanecity.org/charter/ "City Charter")
  + [Municipal Code](https://my.spokanecity.org/smc/ "Municipal Code")
  + [Maps](https://my.spokanecity.org/opendata/gis/ "Maps & GIS")
* [Administrative](https://my.spokanecity.org/administrative/ "Administrative Services")
  + [Legal](https://my.spokanecity.org/administrative/legal/ "City Attorney's Office")
  + [Claims](https://my.spokanecity.org/administrative/claims/ "Claims")
  + [Public Records](https://my.spokanecity.org/administrative/public-records/ "Public Records")

---

* [Live](https://my.spokanecity.org/live/ "Live in Spokane")
* [Community](https://my.spokanecity.org/community/ "Community Services")
* [Get There](https://my.spokanecity.org/getthere/ "Get There")
* [Household Services](https://my.spokanecity.org/household/ "Household Services")
* [Parking](https://my.spokanecity.org/parking/ "Parking")
* [Neighborhoods](https://my.spokanecity.org/neighborhoods/ "Neighborhoods")
* [Public Safety](https://my.spokanecity.org/publicsafety/ "Public Safety")

* [Work](https://my.spokanecity.org/work/ "Work in Spokane")
* [Doing Business](https://my.spokanecity.org/business/doing-business/ "Doing Business")
* [Jobs & Employment](https://my.spokanecity.org/jobs/ "Jobs & Employment")
* [Projects](https://my.spokanecity.org/projects/ "Projects")
* [Get Started...](https://my.spokanecity.org/getstarted/ "Get Started...")
* [Permits](https://my.spokanecity.org/permits/ "Permits")
* [Purchasing](https://my.spokanecity.org/administrative/purchasing/ "Purchasing")

* [Enjoy](https://my.spokanecity.org/enjoy/ "Enjoy & Have Fun!")
* [Arts & Culture](https://my.spokanecity.org/arts/ "Arts & Culture")
* [Riverfront Spokane](https://my.spokanecity.org/riverfrontspokane/ "Riverfront Spokane")
* [Golf](https://my.spokanecity.org/golf/ "Golf")
* [Parks](https://my.spokanecity.org/parks/ "Parks")
* [Recreation](https://my.spokanecity.org/recreation/ "Recreation")
* [Visit Spokane](http://www.visitspokane.com/ "Spokane Hotels, Events, Restaurants & Things to Do")

* [Engage](https://my.spokanecity.org/engage/ "Engage Spokane")
* [Get Involved](https://my.spokanecity.org/getinvolved/ "Get Involved")
* [Mayor Brown](https://my.spokanecity.org/mayor/ "Mayor Brown")
* [City Council](https://my.spokanecity.org/citycouncil/ "City Council")
* [Police Ombuds](https://my.spokanecity.org/opo/ "Police Ombuds")
* [Budget & Performance](https://my.spokanecity.org/budget/ "Budget & Performance Measures")
* [Elections](https://my.spokanecity.org/elections/ "Elections & Voting")

---

* [X/Twitter](https://twitter.com/spokanecity/ "Follow us on X/Twitter")
* [Facebook](https://facebook.com/spokanecity/ "Find us on Facebook")
* [YouTube](https://youtube.com/cityofspokane/ "Watch us on YouTube")
* [Vimeo](https://vimeo.com/spokanecity/ "Watch us on Vimeo")
* [Instagram](https://instagram.com/spokanecity/ "See us on Instagram")

[Back Top](https://my.spokanecity.org/citycouncil/members/zack-zappone/#Top "Back Top")

* [Terms of Use](https://my.spokanecity.org/website/terms/ "Terms of Use & Disclaimer")
* [Your Privacy](https://my.spokanecity.org/website/privacy/ "Privacy Policy")
* Legal Notices

* [City of Spokane](https://my.spokanecity.org/about/ "City of Spokane")
* [Washington](https://access.wa.gov/ "State of Washington")
* [USA](https://www.usa.gov/ "United States of America")